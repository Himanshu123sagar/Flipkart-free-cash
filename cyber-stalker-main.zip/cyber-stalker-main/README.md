# cyber-stalker
Cyber stalker is web-application based tool that helps in catching cyber stalker or fake account users with social engineering.



## One Time Installation

You need a web hosting service  like 000webhost to host Cyber stalker tool. 
    
## How To Setup

- Download/Clone Cyberstalker repo on your PC storage

- Upload Cyberstalker Files on your hosting

- webisiteUrl/panel.php
- Default ID: admin Password: admin
- You can change default Credential in config.php file

Note: You can also use it with apache2 and Ngrok for temporary session

## Screenshots

![App Screenshot](https://github.com/kinghacker0/cyber-stalker/blob/main/Screenshot.jpg)



Join Telegram <a href="https://bio.site/hackersking.in">Hackersking</a>
